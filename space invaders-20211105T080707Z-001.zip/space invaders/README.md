# SpaceInvaders
Making a game with Vanilla JS and HTML Canvas as part of the SDC SI Probation Period

Hosted Site Link: https://spaceinvadersuyashniharika.netlify.app/
